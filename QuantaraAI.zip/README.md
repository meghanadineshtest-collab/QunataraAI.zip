# 🔬 Quantara AI — Institutional Research Engine

> Production-grade research platform that replicates the workflow of a professional
> analyst or consulting firm — in seconds.

---

## ✨ Features

| Feature | Description |
|---|---|
| **Real-Time Data** | Live news, financial data (yfinance), Google Trends |
| **8 Analytical Roles** | Student → Professor → Research Analyst → Investment Analyst → Macro Economist → Futurist → Risk Analyst → Contrarian |
| **Structured Report** | Executive Summary, Key Insights, Market Analysis, Competitors, Opportunities, Risks, Future Scope, Strategic Recommendations |
| **9 Visualizations** | Price history, Sentiment pie, Market share, Competitor radar, Trends, TAM/SAM/SOM, Risk matrix, Opp/Risk scatter, News sentiment |
| **Export** | JSON + PDF (or HTML fallback) reports saved locally |
| **Zero-Config Mode** | Runs fully in mock mode without any API keys |

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
cd quantara_ai
pip install -r requirements.txt
```

### 2. Set API keys (optional but recommended)

```bash
cp .env.example .env
# Edit .env with your keys
```

Or set them directly:
```bash
export ANTHROPIC_API_KEY="sk-ant-..."
export NEWSAPI_KEY="your_newsapi_key"
```

### 3. Run the dashboard

```bash
streamlit run main.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## 🔑 API Keys

| Service | Purpose | Free Tier | Link |
|---|---|---|---|
| **Anthropic** | Claude AI analysis | $5 free credit | [console.anthropic.com](https://console.anthropic.com) |
| **NewsAPI** | Real news articles | 100 req/day | [newsapi.org](https://newsapi.org) |
| **GNews** | Alternative news | 100 req/day | [gnews.io](https://gnews.io) |
| **yfinance** | Stock/financial data | Free (no key) | Built-in |
| **pytrends** | Google Trends | Free (no key) | Built-in |

**Without any keys:** The system runs in intelligent mock mode with realistic generated data.

---

## 📁 Architecture

```
quantara_ai/
├── main.py              # Streamlit dashboard & UI (all tabs, charts, layout)
├── data_fetcher.py      # Data collection: news, financials, trends, sentiment
├── analyzer.py          # Structured report generation (8 sections)
├── role_engine.py       # 8-role analytical perspective engine
├── visualizer.py        # Plotly chart generators (9 chart types)
├── formatter.py         # JSON & PDF/HTML export
├── requirements.txt     # Python dependencies
├── .env.example         # API key template
└── quantara_reports/    # Auto-created output directory
    ├── json/            # JSON exports
    └── pdf/             # PDF/HTML exports
```

---

## 📊 Analysis Sections

1. **Executive Summary** — Core thesis, 3-4 paragraphs
2. **Key Insights** — 8 data-driven signals
3. **Market Analysis** — TAM/SAM/SOM, CAGR, segments
4. **Competitor Analysis** — Top 5 players, market share, moat ratings
5. **Opportunities** — 5 strategic opportunities with probability/impact
6. **Risks** — 5 key risks with severity, likelihood, and mitigations
7. **Future Scope** — 1Y / 5Y / 10Y+ outlook
8. **Strategic Recommendations** — 5 actionable recommendations

---

## 🎭 The 8 Analytical Roles

| Role | Focus |
|---|---|
| 🎓 Student | Simple explanation, core concepts |
| 🏛️ Professor | Academic frameworks, structural drivers |
| 🔬 Research Analyst | Data, metrics, evidence-based insights |
| 📊 Investment Analyst | Investment thesis, risk/reward, catalysts |
| 🌐 Macro Economist | GDP, policy, geopolitical implications |
| 🚀 Futurist | 5-20 year projections, paradigm shifts |
| ⚠️ Risk Analyst | Threats, mitigation, stress tests |
| 🔄 Contrarian | Devil's advocate, consensus challenges |

---

## 💡 Example Topics

- Company tickers: `NVDA`, `TSLA`, `AAPL`, `MSFT`
- Themes: `AI in trading`, `quantum computing`, `electric vehicles`
- Assets: `Bitcoin`, `Gold`, `Real estate`
- Concepts: `deglobalization`, `AI regulation`, `space economy`

---

## 📄 License

MIT License — Build freely, iterate relentlessly.
