"""
analyzer.py — Quantara AI
Generates the full structured institutional-grade report:
Executive Summary, Key Insights, Market Analysis, Competitor Analysis,
Opportunities, Risks, Future Scope, Strategic Recommendations.
Uses Claude API when available; falls back to structured mock output.
"""

import os
import json
import requests
from datetime import datetime
from typing import Optional

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
MODEL = "claude-sonnet-4-20250514"


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _call_claude(system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> Optional[str]:
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        return None
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": MODEL,
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }
    try:
        resp = requests.post(ANTHROPIC_API_URL, headers=headers, json=payload, timeout=90)
        resp.raise_for_status()
        return resp.json()["content"][0]["text"].strip()
    except Exception:
        return None


def _fmt_number(n: float) -> str:
    if n >= 1e12:
        return f"${n/1e12:.2f}T"
    if n >= 1e9:
        return f"${n/1e9:.2f}B"
    if n >= 1e6:
        return f"${n/1e6:.2f}M"
    return f"${n:,.0f}"


def _build_context_summary(topic: str, data: dict) -> str:
    fin = data.get("financial", {})
    sentiment = data.get("sentiment", {})
    news = data.get("news", [])
    headlines = "\n".join(f"- {n['title']}" for n in news[:8])

    return f"""
TOPIC: {topic}
DATE: {datetime.now().strftime('%B %d, %Y')}

FINANCIAL SNAPSHOT:
- Ticker: {fin.get('ticker', 'N/A')} | Sector: {fin.get('sector', 'N/A')}
- Market Cap: {_fmt_number(fin.get('market_cap', 0))}
- Current Price: ${fin.get('current_price', 0):,.2f}
- Revenue: {_fmt_number(fin.get('revenue', 0))}
- PE Ratio: {fin.get('pe_ratio', 'N/A')}
- 52W High: ${fin.get('52w_high', 0):,.2f} | 52W Low: ${fin.get('52w_low', 0):,.2f}
- Analyst Target: ${fin.get('analyst_target', 0):,.2f}
- Recommendation: {fin.get('recommendation', 'N/A').upper()}

MARKET SENTIMENT: {sentiment.get('label', 'Neutral')} ({sentiment.get('composite_score', 0):+.3f})
Positive: {sentiment.get('positive_pct', 0)}% | Neutral: {sentiment.get('neutral_pct', 0)}% | Negative: {sentiment.get('negative_pct', 0)}%

RECENT NEWS:
{headlines}

COMPANY DESCRIPTION:
{fin.get('description', '')[:400]}
"""


# ─────────────────────────────────────────────────────────────────────────────
# SECTION GENERATORS
# ─────────────────────────────────────────────────────────────────────────────

def generate_executive_summary(topic: str, data: dict) -> str:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are the lead analyst at a Goldman Sachs-tier research division. "
        "Write an authoritative Executive Summary for an institutional research report. "
        "3-4 paragraphs. Lead with the core thesis. Be specific and cite data. "
        "Professional tone. No bullet points."
    )
    prompt = f"{ctx}\n\nWrite the Executive Summary for a research report on '{topic}'."
    text = _call_claude(system, prompt, max_tokens=600)
    if text:
        return text

    fin = data.get("financial", {})
    mc = _fmt_number(fin.get("market_cap", 0))
    sentiment_label = data.get("sentiment", {}).get("label", "Neutral")
    rec = fin.get("recommendation", "hold").upper()

    return (
        f"{topic} represents one of the most significant investment and strategic opportunities of the "
        f"current decade. With a market capitalization of {mc} and a consensus analyst recommendation "
        f"of {rec}, the sector is at an inflection point driven by accelerating adoption, institutional "
        f"capital inflows, and structural demand tailwinds that are proving durable across economic cycles.\n\n"
        f"Our analysis reveals a {sentiment_label} market environment underpinned by strong fundamental "
        f"drivers. Revenue growth trajectories, margin expansion potential, and competitive positioning "
        f"collectively support a constructive medium-term outlook. The current macroeconomic backdrop — "
        f"while presenting headwinds in the form of elevated interest rates and geopolitical uncertainty — "
        f"has not materially impaired the core investment case.\n\n"
        f"Key catalysts on the horizon include regulatory developments, international market expansion, "
        f"and continued technological innovation. Risks remain, particularly around valuation compression "
        f"and competitive disruption, but our risk-adjusted return analysis favors exposure to this theme. "
        f"This report provides a comprehensive institutional-grade assessment across eight analytical "
        f"frameworks to equip decision-makers with the full spectrum of perspectives."
    )


def generate_key_insights(topic: str, data: dict) -> list[str]:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are a senior research analyst. Generate exactly 8 key insights as a JSON array of strings. "
        "Each insight must be specific, data-driven, and actionable. No generic statements. "
        "Return ONLY valid JSON array. Example: [\"Insight 1\", \"Insight 2\", ...]"
    )
    prompt = f"{ctx}\n\nGenerate 8 key insights about '{topic}'. Return ONLY a JSON array of strings."
    text = _call_claude(system, prompt, max_tokens=700)
    if text:
        try:
            import re
            match = re.search(r'\[.*\]', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass

    fin = data.get("financial", {})
    mc = _fmt_number(fin.get("market_cap", 0))
    return [
        f"Market capitalization of {mc} signals strong institutional conviction in {topic}'s long-term growth trajectory.",
        f"Analyst consensus of '{fin.get('recommendation','hold').upper()}' with target of ${fin.get('analyst_target',0):,.2f} implies meaningful upside potential.",
        f"Sentiment indicator reads {data.get('sentiment',{}).get('label','Neutral')} — a leading signal for near-term price action.",
        f"PE ratio of {fin.get('pe_ratio','N/A')}x reflects premium growth expectations; justified by sector fundamentals.",
        f"52-week range of ${fin.get('52w_low',0):,.2f}–${fin.get('52w_high',0):,.2f} reveals significant volatility and multiple re-entry opportunities.",
        f"{topic} is benefiting from secular tailwinds in AI, automation, and digital transformation that compound annually.",
        f"Revenue of {_fmt_number(fin.get('revenue',0))} with {fin.get('profit_margin',0)*100:.1f}% profit margins demonstrates scalable business model.",
        f"Geopolitical tailwinds and domestic policy support are creating a favorable regulatory environment for sustained growth.",
    ]


def generate_market_analysis(topic: str, data: dict) -> dict:
    fin = data.get("financial", {})
    mc = fin.get("market_cap", 0)
    rev = fin.get("revenue", 0)

    ctx = _build_context_summary(topic, data)
    system = (
        "You are a market sizing expert. Return ONLY valid JSON with keys: "
        "total_market_size, current_penetration_pct, cagr_pct, market_segments, tam_sam_som, commentary. "
        "market_segments is an array of objects with 'name' and 'share_pct' (should sum to 100). "
        "All values must be realistic. Return ONLY JSON."
    )
    prompt = f"{ctx}\n\nGenerate market size analysis for '{topic}'."
    text = _call_claude(system, prompt, max_tokens=600)
    if text:
        try:
            import re
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass

    import random
    rng = random.Random(hash(topic) % 7777)
    total_market = max(mc * rng.uniform(8, 20), 50_000_000_000)
    segments = [
        ("Enterprise Solutions", rng.randint(25, 35)),
        ("Consumer Applications", rng.randint(15, 25)),
        ("Cloud Infrastructure", rng.randint(15, 20)),
        ("Professional Services", rng.randint(10, 15)),
        ("Other", 0),
    ]
    total_seg = sum(s[1] for s in segments[:-1])
    segments[-1] = ("Other", 100 - total_seg)

    return {
        "total_market_size": _fmt_number(total_market),
        "current_penetration_pct": round(rng.uniform(8, 25), 1),
        "cagr_pct": round(rng.uniform(18, 42), 1),
        "market_segments": [{"name": n, "share_pct": p} for n, p in segments],
        "tam_sam_som": {
            "TAM": _fmt_number(total_market),
            "SAM": _fmt_number(total_market * 0.35),
            "SOM": _fmt_number(total_market * 0.07),
        },
        "commentary": (
            f"The {topic} market is at an early-to-mid stage of a secular growth cycle. "
            f"Total addressable market of {_fmt_number(total_market)} is expanding at "
            f"{round(rng.uniform(18, 42), 1)}% CAGR, driven by enterprise digitization and "
            f"AI adoption. Current market penetration leaves significant runway for growth."
        ),
    }


def generate_competitor_analysis(topic: str, data: dict) -> list[dict]:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are a competitive intelligence analyst. Return ONLY valid JSON array of 5 competitors. "
        "Each object must have: name, market_share_pct, strengths, weaknesses, moat_rating (1-10). "
        "market_share_pct values should sum to approximately 100. Be realistic. Return ONLY JSON array."
    )
    prompt = f"{ctx}\n\nIdentify the top 5 competitors in the '{topic}' space."
    text = _call_claude(system, prompt, max_tokens=700)
    if text:
        try:
            import re
            match = re.search(r'\[.*\]', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass

    import random
    rng = random.Random(hash(topic) % 3333)
    companies = [
        ("Market Leader", 32, "First-mover advantage, strong brand, deep pockets", "Bureaucratic, slow to innovate", 9),
        ("Challenger A", 21, "Aggressive pricing, modern tech stack, talent magnet", "Unprofitable, burn rate concerns", 7),
        ("Challenger B", 17, "Enterprise relationships, regulatory expertise", "Legacy architecture, slow sales cycle", 6),
        ("Niche Player", 11, "Specialized vertical, exceptional NPS, sticky customers", "Limited scale, funding dependent", 5),
        ("Disruptor", 8, "Breakthrough technology, viral growth, community-led", "Unproven at scale, regulatory risk", 8),
    ]

    result = []
    for name, share, strength, weakness, moat in companies:
        result.append({
            "name": name,
            "market_share_pct": share + rng.randint(-3, 3),
            "strengths": strength,
            "weaknesses": weakness,
            "moat_rating": moat,
        })
    return result


def generate_opportunities(topic: str, data: dict) -> list[dict]:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are a strategic opportunity analyst. Return ONLY valid JSON array of 5 opportunities. "
        "Each object: title, description, time_horizon (near/medium/long), impact (high/medium/low), probability_pct. "
        "Return ONLY JSON array."
    )
    prompt = f"{ctx}\n\nIdentify 5 key strategic opportunities for '{topic}'."
    text = _call_claude(system, prompt, max_tokens=700)
    if text:
        try:
            import re
            match = re.search(r'\[.*\]', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass

    return [
        {"title": "AI Integration Acceleration", "description": f"Embedding AI capabilities into {topic} workflows can drive 30-40% productivity gains and create defensible competitive advantages.", "time_horizon": "near", "impact": "high", "probability_pct": 78},
        {"title": "Geographic Expansion", "description": "Untapped markets in Southeast Asia, Africa, and Latin America represent a 4x TAM expansion opportunity with limited incumbent competition.", "time_horizon": "medium", "impact": "high", "probability_pct": 62},
        {"title": "Enterprise Platform Strategy", "description": "Transitioning to a platform model with API monetization and partner ecosystem could triple revenue per customer.", "time_horizon": "medium", "impact": "high", "probability_pct": 55},
        {"title": "Regulatory Arbitrage", "description": "Proactive regulatory engagement ahead of legislation creates first-mover advantage in compliance and establishes industry standards.", "time_horizon": "near", "impact": "medium", "probability_pct": 70},
        {"title": "M&A Consolidation Play", "description": "Fragmented competitive landscape presents acquisition opportunities to build capabilities and eliminate competition simultaneously.", "time_horizon": "long", "impact": "high", "probability_pct": 45},
    ]


def generate_risks(topic: str, data: dict) -> list[dict]:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are a chief risk officer. Return ONLY valid JSON array of 5 risks. "
        "Each object: title, description, category, severity (critical/high/medium/low), likelihood_pct, mitigation. "
        "Return ONLY JSON array."
    )
    prompt = f"{ctx}\n\nIdentify 5 key risks for '{topic}'."
    text = _call_claude(system, prompt, max_tokens=700)
    if text:
        try:
            import re
            match = re.search(r'\[.*\]', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass

    return [
        {"title": "Regulatory Crackdown", "description": "Intensifying global regulation could impose significant compliance costs and operational constraints.", "category": "Regulatory", "severity": "high", "likelihood_pct": 65, "mitigation": "Proactive regulatory affairs team, policy engagement, compliance infrastructure"},
        {"title": "Valuation Compression", "description": "Rate environment and risk-off sentiment could compress multiples 25-40% independent of business fundamentals.", "category": "Market", "severity": "high", "likelihood_pct": 50, "mitigation": "Hedging strategies, focus on cash flow generation to support intrinsic value"},
        {"title": "Competitive Disruption", "description": "Open-source alternatives and well-funded new entrants could commoditize current competitive advantages.", "category": "Competitive", "severity": "critical", "likelihood_pct": 40, "mitigation": "Accelerated R&D investment, platform lock-in, proprietary data moats"},
        {"title": "Macroeconomic Deterioration", "description": "Global recession risk could slow enterprise spending and reduce growth multiples significantly.", "category": "Macro", "severity": "medium", "likelihood_pct": 35, "mitigation": "Geographic diversification, variable cost structure, recession-resistant use cases"},
        {"title": "Cybersecurity & Data Breach", "description": "Expanding attack surface with scale increases risk of material security incidents and reputational damage.", "category": "Operational", "severity": "high", "likelihood_pct": 30, "mitigation": "Zero-trust architecture, bug bounty programs, cyber insurance, incident response planning"},
    ]


def generate_future_scope(topic: str, data: dict) -> str:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are a futures analyst at a top strategy consultancy. Write a 3-5 paragraph future scope "
        "analysis with near-term (1-2 year), medium-term (3-5 year), and long-term (10+ year) outlook. "
        "Be specific with projections. Professional analytical tone."
    )
    prompt = f"{ctx}\n\nWrite the Future Scope section for '{topic}'."
    text = _call_claude(system, prompt, max_tokens=600)
    if text:
        return text

    fin = data.get("financial", {})
    mc = _fmt_number(fin.get("market_cap", 0))

    return (
        f"**Near-Term Outlook (1–2 Years):** {topic} is positioned for continued momentum as institutional "
        f"adoption accelerates and key product cycles mature. We expect 20-30% revenue growth with improving "
        f"margin profiles as operational leverage kicks in. The current market cap of {mc} is likely to "
        f"see valuation multiple expansion as earnings visibility improves.\n\n"
        f"**Medium-Term Outlook (3–5 Years):** The competitive landscape will consolidate around 2-3 dominant "
        f"players, with {topic} well-positioned among the frontrunners. International expansion, particularly "
        f"in emerging markets, will become a primary growth driver. AI-native product features will become "
        f"table stakes, creating new moats for those who move fastest. Market size could expand 3-5x from "
        f"current levels.\n\n"
        f"**Long-Term Vision (10+ Years):** The paradigm shift enabled by {topic} will be as transformative "
        f"as the internet or mobile revolution. The total addressable market could exceed current estimates "
        f"by an order of magnitude as adjacent markets are disrupted and new categories emerge. Companies "
        f"that establish platform dominance in the next 3-5 years will capture disproportionate long-term value. "
        f"The winners will likely be unrecognizable from their current form — having evolved into multi-product, "
        f"multi-market enterprises with network effects that make displacement nearly impossible."
    )


def generate_strategic_recommendations(topic: str, data: dict) -> list[dict]:
    ctx = _build_context_summary(topic, data)
    system = (
        "You are a McKinsey senior partner. Return ONLY valid JSON array of 5 strategic recommendations. "
        "Each object: recommendation, rationale, priority (1=highest), stakeholder, expected_outcome. "
        "Return ONLY JSON array."
    )
    prompt = f"{ctx}\n\nGenerate 5 strategic recommendations for stakeholders in '{topic}'."
    text = _call_claude(system, prompt, max_tokens=700)
    if text:
        try:
            import re
            match = re.search(r'\[.*\]', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass

    return [
        {"recommendation": "Establish AI-Native Infrastructure Now", "rationale": "The cost of building AI capabilities from scratch increases 40% each year as talent and compute prices rise.", "priority": 1, "stakeholder": "C-Suite / Board", "expected_outcome": "2-3x productivity improvement and defensible competitive moat within 18 months"},
        {"recommendation": "Build Strategic Partnerships Ahead of Competition", "rationale": "Distribution and ecosystem partnerships are becoming the primary competitive battlefield as product features commoditize.", "priority": 2, "stakeholder": "Business Development", "expected_outcome": "3-5x accelerated market penetration without proportional cost increase"},
        {"recommendation": "Proactive Regulatory Strategy", "rationale": "Companies that help write the rules gain 12-18 month competitive advantages over those who merely comply.", "priority": 3, "stakeholder": "Legal / Government Affairs", "expected_outcome": "Favorable regulatory framework positioning and avoidance of compliance penalties"},
        {"recommendation": "Talent Acquisition War Chest", "rationale": "Human capital in this sector is the scarcest resource — top 10% performers deliver 10x median output.", "priority": 4, "stakeholder": "HR / People Ops", "expected_outcome": "Sustained innovation pipeline and retention of key IP creators"},
        {"recommendation": "Data Moat Development", "rationale": "Proprietary data compounds in value over time and becomes increasingly expensive for competitors to replicate.", "priority": 5, "stakeholder": "Product / Engineering", "expected_outcome": "Durable competitive advantage that appreciates as AI models improve"},
    ]


# ─────────────────────────────────────────────────────────────────────────────
# MASTER ANALYSIS FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def generate_full_report(topic: str, data: dict, progress_callback=None) -> dict:
    """Generate the complete structured analysis report."""

    sections = [
        ("executive_summary", "Executive Summary"),
        ("key_insights", "Key Insights"),
        ("market_analysis", "Market Analysis"),
        ("competitor_analysis", "Competitor Analysis"),
        ("opportunities", "Opportunities"),
        ("risks", "Risks"),
        ("future_scope", "Future Scope"),
        ("strategic_recommendations", "Strategic Recommendations"),
    ]

    report = {"topic": topic, "generated_at": datetime.now().isoformat()}

    generators = {
        "executive_summary": generate_executive_summary,
        "key_insights": generate_key_insights,
        "market_analysis": generate_market_analysis,
        "competitor_analysis": generate_competitor_analysis,
        "opportunities": generate_opportunities,
        "risks": generate_risks,
        "future_scope": generate_future_scope,
        "strategic_recommendations": generate_strategic_recommendations,
    }

    for i, (key, label) in enumerate(sections):
        if progress_callback:
            progress_callback(i, len(sections), label)
        report[key] = generators[key](topic, data)

    return report
