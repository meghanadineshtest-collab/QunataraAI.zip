"""
data_fetcher.py — Quantara AI
Handles all external data collection: news, financials, trends, sentiment.
"""

import os
import time
import requests
from datetime import datetime, timedelta
from typing import Optional
import re

# ── Optional heavy deps (graceful fallback if not installed) ─────────────────
try:
    import yfinance as yf
    YF_AVAILABLE = True
except ImportError:
    YF_AVAILABLE = False

try:
    from pytrends.request import TrendReq
    PYTRENDS_AVAILABLE = True
except ImportError:
    PYTRENDS_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# NEWS
# ─────────────────────────────────────────────────────────────────────────────

def fetch_news(topic: str, max_articles: int = 10) -> list[dict]:
    """
    Fetch recent news articles for a topic.
    Uses NewsAPI if NEWSAPI_KEY env var is set; otherwise falls back to
    a lightweight GNews scrape or returns mock data so the system always runs.
    """
    api_key = os.getenv("NEWSAPI_KEY", "")

    if api_key:
        return _fetch_newsapi(topic, api_key, max_articles)
    else:
        return _fetch_gnews_free(topic, max_articles)


def _fetch_newsapi(topic: str, api_key: str, max_articles: int) -> list[dict]:
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": topic,
        "sortBy": "relevancy",
        "pageSize": max_articles,
        "language": "en",
        "apiKey": api_key,
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        articles = []
        for a in data.get("articles", []):
            articles.append({
                "title": a.get("title", ""),
                "description": a.get("description", ""),
                "source": a.get("source", {}).get("name", "Unknown"),
                "url": a.get("url", ""),
                "published_at": a.get("publishedAt", ""),
                "sentiment": _basic_sentiment(
                    (a.get("title", "") or "") + " " + (a.get("description", "") or "")
                ),
            })
        return articles
    except Exception as e:
        return _mock_news(topic, max_articles)


def _fetch_gnews_free(topic: str, max_articles: int) -> list[dict]:
    """GNews free tier (no key required for basic queries)."""
    gnews_key = os.getenv("GNEWS_KEY", "")
    if gnews_key:
        url = "https://gnews.io/api/v4/search"
        params = {"q": topic, "lang": "en", "max": max_articles, "token": gnews_key}
        try:
            resp = requests.get(url, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            articles = []
            for a in data.get("articles", []):
                articles.append({
                    "title": a.get("title", ""),
                    "description": a.get("description", ""),
                    "source": a.get("source", {}).get("name", "Unknown"),
                    "url": a.get("url", ""),
                    "published_at": a.get("publishedAt", ""),
                    "sentiment": _basic_sentiment(
                        (a.get("title", "") or "") + " " + (a.get("description", "") or "")
                    ),
                })
            return articles
        except Exception:
            pass
    return _mock_news(topic, max_articles)


def _mock_news(topic: str, n: int) -> list[dict]:
    """Deterministic mock so the app works without any API key."""
    base_date = datetime.now()
    mocks = []
    templates = [
        ("Analysts bullish on {t} amid strong fundamentals", "positive"),
        ("{t} sector sees record investment in Q1 2025", "positive"),
        ("Growing concerns around {t} regulation globally", "negative"),
        ("{t}: What institutional investors are watching", "neutral"),
        ("Deep dive: The future of {t} and market implications", "neutral"),
        ("{t} outperforms expectations — here's why", "positive"),
        ("Risk factors every {t} investor should know", "negative"),
        ("{t} trend accelerates as adoption widens", "positive"),
    ]
    for i, (tmpl, sent) in enumerate(templates[:n]):
        mocks.append({
            "title": tmpl.format(t=topic),
            "description": f"In-depth coverage of {topic} covering recent developments, market outlook, and key drivers.",
            "source": ["Reuters", "Bloomberg", "Financial Times", "WSJ", "CNBC"][i % 5],
            "url": f"https://example.com/article-{i+1}",
            "published_at": (base_date - timedelta(hours=i * 6)).isoformat(),
            "sentiment": sent,
        })
    return mocks


# ─────────────────────────────────────────────────────────────────────────────
# FINANCIAL DATA
# ─────────────────────────────────────────────────────────────────────────────

def fetch_financial_data(topic: str) -> dict:
    """
    Try to resolve topic → stock ticker and pull live data via yfinance.
    Falls back to mock data if resolution fails or yfinance unavailable.
    """
    ticker = _resolve_ticker(topic)

    if YF_AVAILABLE and ticker:
        return _fetch_yfinance(ticker, topic)
    else:
        return _mock_financial(topic, ticker)


def _resolve_ticker(topic: str) -> Optional[str]:
    """Heuristic: if topic looks like a ticker, use it; else map common names."""
    mapping = {
        "tesla": "TSLA", "apple": "AAPL", "microsoft": "MSFT",
        "google": "GOOGL", "alphabet": "GOOGL", "amazon": "AMZN",
        "meta": "META", "facebook": "META", "nvidia": "NVDA",
        "netflix": "NFLX", "bitcoin": "BTC-USD", "ethereum": "ETH-USD",
        "sp500": "^GSPC", "s&p500": "^GSPC", "nasdaq": "^IXIC",
        "openai": None, "ai": None,
    }
    cleaned = topic.lower().strip()
    for k, v in mapping.items():
        if k in cleaned:
            return v
    # If topic is 1-5 uppercase letters, treat as ticker
    if re.match(r"^[A-Z]{1,5}$", topic.strip()):
        return topic.strip()
    return None


def _fetch_yfinance(ticker: str, topic: str) -> dict:
    try:
        t = yf.Ticker(ticker)
        info = t.info or {}
        hist = t.history(period="6mo")

        price_data = []
        if not hist.empty:
            for date, row in hist.iterrows():
                price_data.append({
                    "date": date.strftime("%Y-%m-%d"),
                    "close": round(float(row["Close"]), 2),
                    "volume": int(row["Volume"]),
                })

        return {
            "ticker": ticker,
            "name": info.get("longName", topic),
            "sector": info.get("sector", "Technology"),
            "industry": info.get("industry", "N/A"),
            "current_price": info.get("currentPrice") or info.get("regularMarketPrice", 0),
            "market_cap": info.get("marketCap", 0),
            "pe_ratio": info.get("trailingPE", 0),
            "52w_high": info.get("fiftyTwoWeekHigh", 0),
            "52w_low": info.get("fiftyTwoWeekLow", 0),
            "revenue": info.get("totalRevenue", 0),
            "profit_margin": info.get("profitMargins", 0),
            "analyst_target": info.get("targetMeanPrice", 0),
            "recommendation": info.get("recommendationKey", "hold"),
            "description": info.get("longBusinessSummary", "")[:500],
            "price_history": price_data,
            "data_source": "yfinance (live)",
        }
    except Exception:
        return _mock_financial(topic, ticker)


def _mock_financial(topic: str, ticker: Optional[str]) -> dict:
    import random, math
    rng = random.Random(hash(topic) % 10000)
    base = rng.uniform(50, 500)
    dates = [(datetime.now() - timedelta(days=180 - i * 3)).strftime("%Y-%m-%d")
             for i in range(60)]
    prices = [round(base * (1 + math.sin(i / 10) * 0.1 + rng.uniform(-0.03, 0.03)), 2)
              for i in range(60)]

    return {
        "ticker": ticker or "N/A",
        "name": topic,
        "sector": "Technology",
        "industry": "Software & Services",
        "current_price": prices[-1],
        "market_cap": int(base * 1_000_000_000 * rng.uniform(5, 50)),
        "pe_ratio": round(rng.uniform(15, 60), 1),
        "52w_high": round(max(prices) * 1.05, 2),
        "52w_low": round(min(prices) * 0.95, 2),
        "revenue": int(base * 500_000_000 * rng.uniform(1, 10)),
        "profit_margin": round(rng.uniform(0.05, 0.35), 3),
        "analyst_target": round(prices[-1] * rng.uniform(1.05, 1.40), 2),
        "recommendation": rng.choice(["buy", "buy", "hold", "hold", "sell"]),
        "description": f"{topic} is a leading entity in its space, with growing market presence and institutional interest.",
        "price_history": [{"date": d, "close": p, "volume": int(rng.uniform(1e6, 5e7))}
                           for d, p in zip(dates, prices)],
        "data_source": "mock (add NEWSAPI_KEY / yfinance for live data)",
    }


# ─────────────────────────────────────────────────────────────────────────────
# TRENDS
# ─────────────────────────────────────────────────────────────────────────────

def fetch_trends(topic: str) -> dict:
    """Return Google Trends interest-over-time data."""
    if PYTRENDS_AVAILABLE:
        try:
            pt = TrendReq(hl="en-US", tz=360)
            pt.build_payload([topic[:100]], cat=0, timeframe="today 12-m")
            iot = pt.interest_over_time()
            if not iot.empty and topic[:100] in iot.columns:
                series = iot[topic[:100]].reset_index()
                return {
                    "labels": series["date"].dt.strftime("%Y-%m-%d").tolist(),
                    "values": series[topic[:100]].tolist(),
                    "source": "Google Trends",
                }
        except Exception:
            pass
    return _mock_trends(topic)


def _mock_trends(topic: str) -> dict:
    import random, math
    rng = random.Random(hash(topic) % 9999)
    n = 52
    labels = [(datetime.now() - timedelta(weeks=n - i)).strftime("%Y-%m-%d")
              for i in range(n)]
    base = rng.uniform(30, 70)
    values = [
        max(0, min(100, int(base + math.sin(i / 8) * 20 + rng.uniform(-10, 15) + i * 0.3)))
        for i in range(n)
    ]
    return {"labels": labels, "values": values, "source": "mock trends"}


# ─────────────────────────────────────────────────────────────────────────────
# SENTIMENT
# ─────────────────────────────────────────────────────────────────────────────

def fetch_sentiment(topic: str, news: list[dict]) -> dict:
    """Aggregate sentiment from fetched news articles."""
    counts = {"positive": 0, "neutral": 0, "negative": 0}
    for article in news:
        s = article.get("sentiment", "neutral")
        counts[s] = counts.get(s, 0) + 1

    total = sum(counts.values()) or 1
    score = (counts["positive"] - counts["negative"]) / total

    return {
        "positive_pct": round(counts["positive"] / total * 100, 1),
        "neutral_pct": round(counts["neutral"] / total * 100, 1),
        "negative_pct": round(counts["negative"] / total * 100, 1),
        "composite_score": round(score, 3),          # -1 to +1
        "label": "Bullish" if score > 0.2 else ("Bearish" if score < -0.2 else "Neutral"),
        "counts": counts,
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _basic_sentiment(text: str) -> str:
    positive_words = {
        "surge", "soar", "rally", "gain", "profit", "growth", "bullish",
        "outperform", "record", "beat", "strong", "positive", "rise",
        "innovation", "opportunity", "optimistic", "upgrade",
    }
    negative_words = {
        "crash", "fall", "drop", "loss", "decline", "bearish", "risk",
        "concern", "warning", "threat", "fear", "cut", "miss", "weak",
        "downgrade", "lawsuit", "fine", "crisis",
    }
    tokens = set(text.lower().split())
    pos = len(tokens & positive_words)
    neg = len(tokens & negative_words)
    if pos > neg:
        return "positive"
    if neg > pos:
        return "negative"
    return "neutral"


# ─────────────────────────────────────────────────────────────────────────────
# MASTER COLLECTOR
# ─────────────────────────────────────────────────────────────────────────────

def collect_all_data(topic: str) -> dict:
    """Single entry point — collect everything needed for analysis."""
    print(f"  📡 Fetching news for '{topic}'...")
    news = fetch_news(topic, max_articles=10)

    print(f"  💹 Fetching financial data...")
    financial = fetch_financial_data(topic)

    print(f"  📈 Fetching trends...")
    trends = fetch_trends(topic)

    print(f"  💬 Computing sentiment...")
    sentiment = fetch_sentiment(topic, news)

    return {
        "topic": topic,
        "collected_at": datetime.now().isoformat(),
        "news": news,
        "financial": financial,
        "trends": trends,
        "sentiment": sentiment,
    }
