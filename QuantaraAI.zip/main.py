"""
main.py — Quantara AI
Streamlit dashboard entry point.
Run with: streamlit run main.py
"""

import streamlit as st
import json
import time
from pathlib import Path
from datetime import datetime

# ─────────────────────────────────────────────────────────────────────────────
# PAGE CONFIG (must be first Streamlit call)
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Quantara AI — Institutional Research",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─────────────────────────────────────────────────────────────────────────────
# CUSTOM CSS — dark, premium, institutional aesthetic
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

:root {
    --bg: #0D0D0D;
    --card: #151515;
    --card2: #1C1C1C;
    --border: #272727;
    --primary: #0A84FF;
    --green: #30D158;
    --red: #FF453A;
    --yellow: #FFD60A;
    --purple: #BF5AF2;
    --teal: #5AC8FA;
    --text: #F5F5F7;
    --muted: #6E6E73;
    --font: 'Space Grotesk', sans-serif;
    --mono: 'JetBrains Mono', monospace;
}

/* Reset + global */
.stApp { background: var(--bg) !important; font-family: var(--font); }
* { box-sizing: border-box; }

/* Hide default streamlit elements */
#MainMenu, footer, header { visibility: hidden; }
.block-container { padding: 0 !important; max-width: 100% !important; }

/* ── HEADER ── */
.q-header {
    background: linear-gradient(135deg, #0D0D0D 0%, #111827 50%, #0D0D0D 100%);
    border-bottom: 1px solid var(--border);
    padding: 28px 48px 24px;
    position: relative;
    overflow: hidden;
}
.q-header::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: radial-gradient(ellipse at 20% 50%, rgba(10,132,255,0.08) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 50%, rgba(191,90,242,0.06) 0%, transparent 60%);
    pointer-events: none;
}
.q-brand {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 4px;
    color: var(--primary);
    text-transform: uppercase;
    margin-bottom: 4px;
}
.q-title {
    font-size: 36px;
    font-weight: 700;
    color: var(--text);
    margin: 0;
    line-height: 1.1;
}
.q-title span { color: var(--primary); }
.q-subtitle {
    font-size: 14px;
    color: var(--muted);
    margin-top: 6px;
}

/* ── SEARCH SECTION ── */
.q-search-wrap {
    padding: 40px 48px 32px;
    border-bottom: 1px solid var(--border);
}

/* ── METRIC CARDS ── */
.metric-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    padding: 24px 48px;
}
.metric-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 18px 20px;
    transition: all 0.2s ease;
}
.metric-card:hover { border-color: var(--primary); transform: translateY(-1px); }
.metric-label {
    font-size: 11px;
    font-weight: 500;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 6px;
}
.metric-value {
    font-size: 22px;
    font-weight: 700;
    color: var(--text);
    font-family: var(--mono);
}
.metric-sub {
    font-size: 11px;
    color: var(--muted);
    margin-top: 4px;
}
.metric-badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    margin-top: 6px;
}
.badge-buy { background: rgba(48,209,88,0.15); color: var(--green); }
.badge-hold { background: rgba(255,214,10,0.15); color: var(--yellow); }
.badge-sell { background: rgba(255,69,58,0.15); color: var(--red); }
.badge-bullish { background: rgba(48,209,88,0.15); color: var(--green); }
.badge-bearish { background: rgba(255,69,58,0.15); color: var(--red); }
.badge-neutral { background: rgba(110,110,115,0.2); color: var(--muted); }

/* ── MAIN CONTENT ── */
.q-content { padding: 24px 48px; }

/* ── SECTION HEADERS ── */
.section-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 36px 0 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--border);
}
.section-icon { font-size: 20px; }
.section-title {
    font-size: 18px;
    font-weight: 600;
    color: var(--text);
    margin: 0;
}
.section-tag {
    font-size: 10px;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--muted);
    padding: 3px 10px;
    border: 1px solid var(--border);
    border-radius: 20px;
    margin-left: auto;
}

/* ── EXEC SUMMARY ── */
.exec-summary {
    background: linear-gradient(135deg, var(--card) 0%, var(--card2) 100%);
    border: 1px solid var(--border);
    border-left: 3px solid var(--primary);
    border-radius: 12px;
    padding: 28px 32px;
    line-height: 1.85;
    font-size: 15px;
    color: #D1D1D6;
}
.exec-summary p { margin-bottom: 16px; }
.exec-summary p:last-child { margin-bottom: 0; }

/* ── INSIGHT CARDS ── */
.insights-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
}
.insight-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px 18px;
    display: flex;
    gap: 12px;
    align-items: flex-start;
    transition: border-color 0.2s;
}
.insight-card:hover { border-color: var(--primary); }
.insight-num {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--primary);
    font-weight: 600;
    min-width: 24px;
    padding-top: 2px;
}
.insight-text { font-size: 13px; color: #C7C7CC; line-height: 1.6; }

/* ── ROLE CARDS ── */
.roles-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
}
.role-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 22px 24px;
    transition: all 0.2s;
}
.role-card:hover { border-color: rgba(10,132,255,0.4); transform: translateY(-2px); }
.role-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 14px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--border);
}
.role-icon { font-size: 20px; }
.role-name {
    font-size: 14px;
    font-weight: 600;
    color: var(--text);
}
.role-content {
    font-size: 13px;
    color: #AEAEB2;
    line-height: 1.75;
}

/* ── OPPORTUNITY CARDS ── */
.opp-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-left: 3px solid var(--green);
    border-radius: 10px;
    padding: 18px 22px;
    margin-bottom: 12px;
}
.opp-title { font-size: 14px; font-weight: 600; color: var(--text); margin-bottom: 8px; }
.opp-desc { font-size: 13px; color: #AEAEB2; line-height: 1.7; margin-bottom: 10px; }
.opp-meta { display: flex; gap: 10px; flex-wrap: wrap; }
.tag {
    font-size: 11px;
    padding: 3px 10px;
    border-radius: 20px;
    font-weight: 500;
}
.tag-green { background: rgba(48,209,88,0.12); color: var(--green); }
.tag-blue { background: rgba(10,132,255,0.12); color: var(--primary); }
.tag-purple { background: rgba(191,90,242,0.12); color: var(--purple); }
.tag-yellow { background: rgba(255,214,10,0.12); color: var(--yellow); }

/* ── RISK CARDS ── */
.risk-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-left: 3px solid var(--red);
    border-radius: 10px;
    padding: 18px 22px;
    margin-bottom: 12px;
}
.risk-card.severity-medium { border-left-color: #FF6B35; }
.risk-card.severity-low { border-left-color: var(--yellow); }
.risk-title { font-size: 14px; font-weight: 600; color: var(--text); margin-bottom: 8px; }
.risk-desc { font-size: 13px; color: #AEAEB2; line-height: 1.7; margin-bottom: 10px; }
.risk-mitigation {
    font-size: 12px;
    color: var(--muted);
    background: var(--card2);
    padding: 8px 12px;
    border-radius: 6px;
    margin-top: 8px;
}

/* ── FUTURE SCOPE ── */
.future-text {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 24px 28px;
    font-size: 14px;
    color: #C7C7CC;
    line-height: 1.85;
}

/* ── REC CARDS ── */
.rec-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 20px 22px;
    margin-bottom: 12px;
    display: flex;
    gap: 16px;
}
.rec-num {
    font-family: var(--mono);
    font-size: 24px;
    font-weight: 700;
    color: var(--primary);
    min-width: 40px;
    line-height: 1;
    padding-top: 4px;
}
.rec-content {}
.rec-title { font-size: 14px; font-weight: 600; color: var(--text); margin-bottom: 6px; }
.rec-rationale { font-size: 13px; color: #AEAEB2; line-height: 1.7; margin-bottom: 8px; }
.rec-outcome { font-size: 12px; color: var(--green); }

/* ── NEWS CARDS ── */
.news-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 14px 16px;
    margin-bottom: 10px;
    display: flex;
    gap: 14px;
    align-items: flex-start;
}
.news-sentiment-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    margin-top: 5px;
    flex-shrink: 0;
}
.dot-positive { background: var(--green); }
.dot-neutral { background: var(--muted); }
.dot-negative { background: var(--red); }
.news-title { font-size: 13px; color: var(--text); font-weight: 500; margin-bottom: 4px; }
.news-meta { font-size: 11px; color: var(--muted); }

/* ── COMPETITOR TABLE ── */
.comp-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}
.comp-table th {
    background: var(--card2);
    color: var(--muted);
    font-size: 10px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    padding: 12px 16px;
    text-align: left;
    border-bottom: 1px solid var(--border);
}
.comp-table td {
    padding: 12px 16px;
    border-bottom: 1px solid var(--border);
    color: #C7C7CC;
    vertical-align: top;
}
.comp-table tr:hover td { background: var(--card2); }
.moat-bar {
    height: 6px; border-radius: 3px;
    background: linear-gradient(90deg, var(--primary), var(--teal));
    margin-top: 4px;
}

/* ── PROGRESS ── */
.progress-container {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 32px;
    text-align: center;
    margin: 40px 0;
}
.progress-label {
    font-size: 14px;
    color: var(--muted);
    margin-top: 12px;
}

/* ── STREAMLIT OVERRIDES ── */
.stTextInput > div > div > input {
    background: var(--card) !important;
    border: 1px solid var(--border) !important;
    border-radius: 10px !important;
    color: var(--text) !important;
    font-family: var(--font) !important;
    font-size: 16px !important;
    padding: 14px 18px !important;
    height: auto !important;
}
.stTextInput > div > div > input:focus {
    border-color: var(--primary) !important;
    box-shadow: 0 0 0 2px rgba(10,132,255,0.2) !important;
}
.stButton > button {
    background: var(--primary) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    font-family: var(--font) !important;
    font-weight: 600 !important;
    font-size: 15px !important;
    padding: 14px 32px !important;
    cursor: pointer !important;
    transition: all 0.2s !important;
    letter-spacing: 0.3px !important;
}
.stButton > button:hover {
    background: #1a8fff !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 8px 24px rgba(10,132,255,0.3) !important;
}
div[data-testid="stTabs"] button {
    font-family: var(--font) !important;
    color: var(--muted) !important;
    font-size: 13px !important;
}
div[data-testid="stTabs"] button[aria-selected="true"] {
    color: var(--primary) !important;
}
.stSelectbox > div > div {
    background: var(--card) !important;
    border-color: var(--border) !important;
    color: var(--text) !important;
}
.stMarkdown p, .stMarkdown li {
    color: #C7C7CC !important;
    font-family: var(--font) !important;
}

/* Tabs styling */
.stTabs [data-baseweb="tab-list"] {
    background: var(--card2) !important;
    border-radius: 10px !important;
    gap: 4px !important;
    padding: 4px !important;
    border: 1px solid var(--border) !important;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 8px !important;
    padding: 8px 16px !important;
    font-weight: 500 !important;
}
.stTabs [aria-selected="true"] {
    background: var(--primary) !important;
    color: white !important;
}

/* Sidebar */
.css-1d391kg, [data-testid="stSidebar"] {
    background: var(--card) !important;
    border-right: 1px solid var(--border) !important;
}

/* Spinner */
.stSpinner > div { border-top-color: var(--primary) !important; }

/* Download buttons */
.stDownloadButton > button {
    background: transparent !important;
    border: 1px solid var(--border) !important;
    color: var(--text) !important;
    font-family: var(--font) !important;
    font-size: 13px !important;
}
.stDownloadButton > button:hover {
    border-color: var(--primary) !important;
    color: var(--primary) !important;
    transform: none !important;
    box-shadow: none !important;
}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# IMPORTS (after CSS to avoid re-layout)
# ─────────────────────────────────────────────────────────────────────────────

from data_fetcher import collect_all_data
from analyzer import generate_full_report
from role_engine import run_all_roles, ROLES
from visualizer import (
    plot_price_history, plot_sentiment_pie, plot_market_share,
    plot_competitor_comparison, plot_trends, plot_opportunity_risk_matrix,
    plot_tam_sam_som, plot_risk_matrix, plot_news_sentiment,
)
from formatter import save_report_json, save_report_pdf


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def fmt_large(n):
    try:
        n = float(n)
    except:
        return "N/A"
    if n >= 1e12:
        return f"${n/1e12:.2f}T"
    if n >= 1e9:
        return f"${n/1e9:.2f}B"
    if n >= 1e6:
        return f"${n/1e6:.2f}M"
    return f"${n:,.0f}"


def badge(text: str, kind: str) -> str:
    return f'<span class="metric-badge badge-{kind.lower()}">{text.upper()}</span>'


# ─────────────────────────────────────────────────────────────────────────────
# RENDER: HEADER
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<div class="q-header">
    <div class="q-brand">Quantara AI · Research Platform</div>
    <h1 class="q-title">Institutional <span>Research</span> Engine</h1>
    <p class="q-subtitle">Multi-perspective analysis · Real-time data · 8 analytical frameworks · Professional-grade reports</p>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# RENDER: SEARCH
# ─────────────────────────────────────────────────────────────────────────────

st.markdown('<div class="q-search-wrap">', unsafe_allow_html=True)

col1, col2, col3 = st.columns([5, 1.5, 1])
with col1:
    topic_input = st.text_input(
        "",
        placeholder="Enter any topic, company, or ticker — e.g. 'NVIDIA', 'AI in healthcare', 'Bitcoin'",
        label_visibility="collapsed",
        key="topic_input",
    )
with col2:
    analyze_btn = st.button("🔬 Analyze Now", use_container_width=True)
with col3:
    st.markdown(
        '<div style="padding-top: 8px; font-size: 12px; color: #6E6E73; text-align: center;">Powered by Claude AI</div>',
        unsafe_allow_html=True
    )

# Quick examples
st.markdown("""
<div style="margin-top: 12px; display: flex; gap: 8px; flex-wrap: wrap;">
    <span style="font-size: 11px; color: #6E6E73;">Try:</span>
""", unsafe_allow_html=True)

example_topics = ["NVIDIA", "Tesla", "AI in trading", "Bitcoin", "SpaceX", "OpenAI"]
ecols = st.columns(len(example_topics) + 1)
for i, ex in enumerate(example_topics):
    with ecols[i + 1]:
        if st.button(ex, key=f"ex_{ex}", help=f"Analyze {ex}"):
            st.session_state["topic_input"] = ex
            st.session_state["run_topic"] = ex
            st.rerun()

st.markdown("</div>", unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# SESSION STATE
# ─────────────────────────────────────────────────────────────────────────────

if "results" not in st.session_state:
    st.session_state["results"] = None
if "run_topic" not in st.session_state:
    st.session_state["run_topic"] = None


# ─────────────────────────────────────────────────────────────────────────────
# RUN ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

run_topic = st.session_state.get("run_topic") or (topic_input if analyze_btn else None)

if run_topic and run_topic.strip():
    topic = run_topic.strip()

    st.markdown('<div class="q-content">', unsafe_allow_html=True)

    with st.container():
        progress_bar = st.progress(0, text="")
        status_box = st.empty()

        def update_progress(step, total, label):
            pct = int((step + 1) / total * 100)
            progress_bar.progress(min(pct, 100), text=f"Analyzing... {label}")
            status_box.markdown(f"""
            <div style="text-align:center; color: #6E6E73; font-size: 13px; margin: 8px 0;">
                Step {step+1}/{total} — {label}
            </div>
            """, unsafe_allow_html=True)

        # 1. Collect data
        update_progress(0, 5, "Fetching live data & news")
        data = collect_all_data(topic)

        # 2. Generate report
        update_progress(1, 5, "Building institutional analysis")
        report = generate_full_report(topic, data)

        # 3. Run role analyses
        update_progress(2, 5, "Running 8 analytical perspectives")
        role_results = run_all_roles(topic, data)

        # 4. Save outputs
        update_progress(3, 5, "Saving report files")
        json_path = save_report_json(topic, data, report, role_results)
        pdf_path = save_report_pdf(topic, data, report, role_results)

        update_progress(4, 5, "Complete")
        progress_bar.empty()
        status_box.empty()

        st.session_state["results"] = {
            "topic": topic,
            "data": data,
            "report": report,
            "roles": role_results,
            "json_path": str(json_path),
            "pdf_path": str(pdf_path),
        }
        st.session_state["run_topic"] = None

    st.markdown("</div>", unsafe_allow_html=True)
    st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# DISPLAY RESULTS
# ─────────────────────────────────────────────────────────────────────────────

results = st.session_state.get("results")

if results:
    topic = results["topic"]
    data = results["data"]
    report = results["report"]
    roles = results["roles"]
    fin = data.get("financial", {})
    sentiment = data.get("sentiment", {})
    news = data.get("news", [])
    trends = data.get("trends", {})

    st.markdown('<div class="q-content">', unsafe_allow_html=True)

    # ── Topic Banner ──────────────────────────────────────────────────────────
    rec = fin.get("recommendation", "hold")
    sent_label = sentiment.get("label", "Neutral")
    rec_badge = badge(rec, rec)
    sent_badge = badge(sent_label, sent_label)

    st.markdown(f"""
    <div style="background: linear-gradient(135deg, #111 0%, #151515 100%);
                border: 1px solid #272727; border-radius: 14px; padding: 24px 28px; margin-bottom: 8px;">
        <div style="font-size: 11px; letter-spacing: 2px; color: #6E6E73; text-transform: uppercase; margin-bottom: 8px;">
            Research Report · {datetime.now().strftime('%B %d, %Y')}
        </div>
        <div style="font-size: 28px; font-weight: 700; color: #F5F5F7; margin-bottom: 6px;">{topic}</div>
        <div style="font-size: 13px; color: #6E6E73;">
            {fin.get('name', topic)} · {fin.get('sector', 'N/A')} · {fin.get('industry', 'N/A')}
        </div>
        <div style="margin-top: 12px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            {rec_badge} {sent_badge}
            <span style="font-size: 12px; color: #6E6E73; margin-left: 8px;">
                Data: {fin.get('data_source', 'mock')}
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Metrics Grid ──────────────────────────────────────────────────────────
    st.markdown('<div class="metric-grid">', unsafe_allow_html=True)
    metrics = [
        ("Market Cap", fmt_large(fin.get("market_cap", 0)), fin.get("sector", ""), "💰"),
        ("Current Price", f"${fin.get('current_price', 0):,.2f}", f"Target: ${fin.get('analyst_target', 0):,.2f}", "💵"),
        ("PE Ratio", str(fin.get("pe_ratio", "N/A")), f"Profit Margin: {fin.get('profit_margin', 0)*100:.1f}%", "📊"),
        ("Revenue", fmt_large(fin.get("revenue", 0)), f"52W: ${fin.get('52w_low',0):,.0f}–${fin.get('52w_high',0):,.0f}", "📈"),
        ("Sentiment", sentiment.get("label", "N/A"), f"Score: {sentiment.get('composite_score', 0):+.3f}", "💬"),
        ("News Positive", f"{sentiment.get('positive_pct', 0):.0f}%", f"Negative: {sentiment.get('negative_pct', 0):.0f}%", "📰"),
        ("CAGR (Market)", f"{report.get('market_analysis', {}).get('cagr_pct', 0):.0f}%", "Annual Growth Rate", "🚀"),
        ("Market Size", str(report.get('market_analysis', {}).get('total_market_size', 'N/A')), "Total Addressable Market", "🌐"),
    ]

    for label, value, sub, icon in metrics:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">{icon} {label}</div>
            <div class="metric-value">{value}</div>
            <div class="metric-sub">{sub}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("</div>", unsafe_allow_html=True)

    # ── Download Buttons ──────────────────────────────────────────────────────
    st.markdown("<div style='padding: 0 0 8px; display: flex; gap: 12px;'>", unsafe_allow_html=True)
    dcol1, dcol2, dcol3 = st.columns([1, 1, 5])

    json_path = Path(results["json_path"])
    if json_path.exists():
        with open(json_path, "rb") as f:
            dcol1.download_button(
                "⬇ JSON Report",
                f,
                file_name=json_path.name,
                mime="application/json",
            )

    pdf_path = Path(results["pdf_path"])
    if pdf_path.exists():
        mime = "application/pdf" if pdf_path.suffix == ".pdf" else "text/html"
        with open(pdf_path, "rb") as f:
            dcol2.download_button(
                "⬇ PDF/HTML Report",
                f,
                file_name=pdf_path.name,
                mime=mime,
            )
    st.markdown("</div>", unsafe_allow_html=True)

    # ── TABS ──────────────────────────────────────────────────────────────────
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "📋 Report", "🎭 Perspectives", "📊 Charts", "📰 News", "🏢 Competitors", "⚙️ Raw Data"
    ])

    # ════════════════════════════════════════════════════════════════════════
    # TAB 1: REPORT
    # ════════════════════════════════════════════════════════════════════════
    with tab1:
        # Executive Summary
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">📝</span>
            <h2 class="section-title">Executive Summary</h2>
            <span class="section-tag">SYNTHESIS</span>
        </div>
        """, unsafe_allow_html=True)

        exec_html = ""
        for para in report.get("executive_summary", "").split("\n\n"):
            if para.strip():
                exec_html += f"<p>{para.strip()}</p>"
        st.markdown(f'<div class="exec-summary">{exec_html}</div>', unsafe_allow_html=True)

        # Key Insights
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">💡</span>
            <h2 class="section-title">Key Insights</h2>
            <span class="section-tag">8 SIGNALS</span>
        </div>
        """, unsafe_allow_html=True)

        insights = report.get("key_insights", [])
        st.markdown('<div class="insights-grid">', unsafe_allow_html=True)
        for i, insight in enumerate(insights):
            st.markdown(f"""
            <div class="insight-card">
                <div class="insight-num">0{i+1}</div>
                <div class="insight-text">{insight}</div>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        # Opportunities
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">🚀</span>
            <h2 class="section-title">Opportunities</h2>
            <span class="section-tag">UPSIDE DRIVERS</span>
        </div>
        """, unsafe_allow_html=True)

        for opp in report.get("opportunities", []):
            horizon_tag = f'<span class="tag tag-blue">{opp.get("time_horizon","").upper()} TERM</span>'
            impact_tag = f'<span class="tag tag-green">IMPACT: {opp.get("impact","").upper()}</span>'
            prob_tag = f'<span class="tag tag-purple">P: {opp.get("probability_pct",50)}%</span>'
            st.markdown(f"""
            <div class="opp-card">
                <div class="opp-title">{opp.get('title','')}</div>
                <div class="opp-desc">{opp.get('description','')}</div>
                <div class="opp-meta">{horizon_tag}{impact_tag}{prob_tag}</div>
            </div>
            """, unsafe_allow_html=True)

        # Risks
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">⚠️</span>
            <h2 class="section-title">Risk Factors</h2>
            <span class="section-tag">DOWNSIDE THREATS</span>
        </div>
        """, unsafe_allow_html=True)

        for risk in report.get("risks", []):
            sev = risk.get("severity", "medium").lower()
            sev_colors = {"critical": "#FF453A", "high": "#FF6B35", "medium": "#FFD60A", "low": "#30D158"}
            sev_color = sev_colors.get(sev, "#6E6E73")
            st.markdown(f"""
            <div class="risk-card severity-{sev}">
                <div class="risk-title">
                    {risk.get('title','')}
                    <span style="font-size:11px; padding:2px 8px; border-radius:12px;
                                 background: rgba(255,69,58,0.12); color:{sev_color};
                                 font-weight:600; margin-left:8px;">{sev.upper()}</span>
                    <span style="font-size:11px; color:#6E6E73; margin-left:8px;">
                        Likelihood: {risk.get('likelihood_pct',40)}%
                    </span>
                </div>
                <div class="risk-desc">{risk.get('description','')}</div>
                <div class="risk-mitigation">🛡 {risk.get('mitigation','')}</div>
            </div>
            """, unsafe_allow_html=True)

        # Future Scope
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">🔭</span>
            <h2 class="section-title">Future Scope</h2>
            <span class="section-tag">1Y / 5Y / 10Y+ OUTLOOK</span>
        </div>
        """, unsafe_allow_html=True)

        future_html = ""
        for para in report.get("future_scope", "").split("\n\n"):
            if para.strip():
                future_html += f"<p>{para.strip()}</p>"
        st.markdown(f'<div class="future-text">{future_html}</div>', unsafe_allow_html=True)

        # Strategic Recommendations
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">🎯</span>
            <h2 class="section-title">Strategic Recommendations</h2>
            <span class="section-tag">ACTION PLAN</span>
        </div>
        """, unsafe_allow_html=True)

        for i, rec in enumerate(report.get("strategic_recommendations", []), 1):
            st.markdown(f"""
            <div class="rec-card">
                <div class="rec-num">0{i}</div>
                <div class="rec-content">
                    <div class="rec-title">{rec.get('recommendation','')}</div>
                    <div class="rec-rationale">{rec.get('rationale','')}</div>
                    <div class="rec-outcome">✓ {rec.get('expected_outcome','')}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 2: PERSPECTIVES
    # ════════════════════════════════════════════════════════════════════════
    with tab2:
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">🎭</span>
            <h2 class="section-title">8 Analytical Perspectives</h2>
            <span class="section-tag">MULTI-ROLE ANALYSIS</span>
        </div>
        """, unsafe_allow_html=True)

        st.markdown('<div class="roles-grid">', unsafe_allow_html=True)
        for role in roles:
            analysis_html = ""
            for para in role.get("analysis", "").split("\n\n"):
                if para.strip():
                    analysis_html += f"<p>{para.strip()}</p>"
            st.markdown(f"""
            <div class="role-card">
                <div class="role-header">
                    <span class="role-icon">{role.get('icon','')}</span>
                    <span class="role-name">{role.get('label','')}</span>
                </div>
                <div class="role-content">{analysis_html}</div>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 3: CHARTS
    # ════════════════════════════════════════════════════════════════════════
    with tab3:
        # Price History
        if fin.get("price_history"):
            st.markdown("""
            <div class="section-header">
                <span class="section-icon">📈</span>
                <h2 class="section-title">Price History</h2>
                <span class="section-tag">6 MONTHS</span>
            </div>
            """, unsafe_allow_html=True)
            st.plotly_chart(plot_price_history(fin), use_container_width=True, config={"displayModeBar": False})

        # Two columns: sentiment + trends
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("<div style='margin-bottom:8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Market Sentiment</div>", unsafe_allow_html=True)
            st.plotly_chart(plot_sentiment_pie(sentiment), use_container_width=True, config={"displayModeBar": False})

        with c2:
            st.markdown("<div style='margin-bottom:8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Search Trends</div>", unsafe_allow_html=True)
            st.plotly_chart(plot_trends(trends, topic), use_container_width=True, config={"displayModeBar": False})

        # Market sizing
        mkt = report.get("market_analysis", {})
        if mkt:
            st.markdown("<div style='margin:16px 0 8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Market Sizing</div>", unsafe_allow_html=True)
            st.plotly_chart(plot_tam_sam_som(mkt), use_container_width=True, config={"displayModeBar": False})

        # Competitor charts
        comps = report.get("competitor_analysis", [])
        if comps:
            c3, c4 = st.columns(2)
            with c3:
                st.markdown("<div style='margin-bottom:8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Market Share</div>", unsafe_allow_html=True)
                st.plotly_chart(plot_market_share(comps), use_container_width=True, config={"displayModeBar": False})
            with c4:
                st.markdown("<div style='margin-bottom:8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Competitor Radar</div>", unsafe_allow_html=True)
                st.plotly_chart(plot_competitor_comparison(comps), use_container_width=True, config={"displayModeBar": False})

        # Opportunity / risk matrix
        opps = report.get("opportunities", [])
        risks_list = report.get("risks", [])
        if opps and risks_list:
            st.markdown("<div style='margin-top:16px;margin-bottom:8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Opportunity & Risk Matrix</div>", unsafe_allow_html=True)
            st.plotly_chart(plot_opportunity_risk_matrix(opps, risks_list), use_container_width=True, config={"displayModeBar": False})

        # Risk chart
        if risks_list:
            st.markdown("<div style='margin-top:16px;margin-bottom:8px;font-size:14px;font-weight:600;color:#F5F5F7;'>Risk Likelihood</div>", unsafe_allow_html=True)
            st.plotly_chart(plot_risk_matrix(risks_list), use_container_width=True, config={"displayModeBar": False})

        # News sentiment
        if news:
            st.plotly_chart(plot_news_sentiment(news), use_container_width=True, config={"displayModeBar": False})

    # ════════════════════════════════════════════════════════════════════════
    # TAB 4: NEWS
    # ════════════════════════════════════════════════════════════════════════
    with tab4:
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">📰</span>
            <h2 class="section-title">Latest News</h2>
            <span class="section-tag">REAL-TIME FEED</span>
        </div>
        """, unsafe_allow_html=True)

        for article in news:
            dot_class = f"dot-{article.get('sentiment', 'neutral')}"
            pub = article.get("published_at", "")[:10]
            st.markdown(f"""
            <div class="news-card">
                <div class="news-sentiment-dot {dot_class}"></div>
                <div>
                    <div class="news-title">{article.get('title','')}</div>
                    <div style="font-size:13px; color:#AEAEB2; margin: 4px 0 6px;">{article.get('description','')}</div>
                    <div class="news-meta">
                        {article.get('source','Unknown')} · {pub} ·
                        <span style="color: {'#30D158' if article.get('sentiment')=='positive' else '#FF453A' if article.get('sentiment')=='negative' else '#6E6E73'};">
                            {article.get('sentiment','neutral').upper()}
                        </span>
                        {'· <a href="' + article.get('url','') + '" target="_blank" style="color: #0A84FF; text-decoration: none;">Read →</a>' if article.get('url') else ''}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 5: COMPETITORS
    # ════════════════════════════════════════════════════════════════════════
    with tab5:
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">🏢</span>
            <h2 class="section-title">Competitor Analysis</h2>
            <span class="section-tag">COMPETITIVE LANDSCAPE</span>
        </div>
        """, unsafe_allow_html=True)

        comps = report.get("competitor_analysis", [])
        if comps:
            table_rows = ""
            for c in comps:
                moat = c.get("moat_rating", 5)
                bar_width = moat * 10
                table_rows += f"""
                <tr>
                    <td><strong style="color:#F5F5F7;">{c.get('name','')}</strong></td>
                    <td><strong>{c.get('market_share_pct',0):.1f}%</strong></td>
                    <td style="color:#C7C7CC; max-width: 200px;">{c.get('strengths','')}</td>
                    <td style="color:#AEAEB2; max-width: 200px;">{c.get('weaknesses','')}</td>
                    <td>
                        {moat}/10
                        <div class="moat-bar" style="width: {bar_width}%;"></div>
                    </td>
                </tr>
                """

            st.markdown(f"""
            <table class="comp-table">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Market Share</th>
                        <th>Strengths</th>
                        <th>Weaknesses</th>
                        <th>Moat Rating</th>
                    </tr>
                </thead>
                <tbody>{table_rows}</tbody>
            </table>
            """, unsafe_allow_html=True)

        mkt = report.get("market_analysis", {})
        if mkt.get("commentary"):
            st.markdown(f"""
            <div style="margin-top:20px; background: var(--card); border: 1px solid var(--border);
                        border-left: 3px solid var(--primary); border-radius: 10px; padding: 20px 24px;">
                <div style="font-size:12px; letter-spacing:1px; color:#6E6E73; margin-bottom:8px;">MARKET COMMENTARY</div>
                <div style="font-size:14px; color:#C7C7CC; line-height:1.75;">{mkt['commentary']}</div>
            </div>
            """, unsafe_allow_html=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 6: RAW DATA
    # ════════════════════════════════════════════════════════════════════════
    with tab6:
        st.markdown("""
        <div class="section-header">
            <span class="section-icon">⚙️</span>
            <h2 class="section-title">Raw Data</h2>
            <span class="section-tag">JSON EXPORT</span>
        </div>
        """, unsafe_allow_html=True)

        view_data = {
            "financial_snapshot": {k: v for k, v in fin.items() if k != "price_history"},
            "sentiment": sentiment,
            "market_analysis": report.get("market_analysis", {}),
            "news_sample": news[:3],
        }
        st.json(view_data)

    st.markdown("</div>", unsafe_allow_html=True)

else:
    # ── Welcome / Landing State ────────────────────────────────────────────
    st.markdown("""
    <div style="padding: 60px 48px; text-align: center;">
        <div style="font-size: 72px; margin-bottom: 20px;">🔬</div>
        <div style="font-size: 24px; font-weight: 600; color: #F5F5F7; margin-bottom: 12px;">
            Enter a topic to begin your research
        </div>
        <div style="font-size: 15px; color: #6E6E73; max-width: 500px; margin: 0 auto; line-height: 1.7;">
            Quantara AI generates institutional-grade research with real-time data,
            multi-perspective analysis, and professional visualizations — in seconds.
        </div>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;
                    max-width: 800px; margin: 40px auto 0; text-align: left;">
            <div style="background: #151515; border: 1px solid #272727; border-radius: 12px; padding: 20px;">
                <div style="font-size: 24px; margin-bottom: 10px;">📡</div>
                <div style="font-size: 13px; font-weight: 600; color: #F5F5F7;">Real-Time Data</div>
                <div style="font-size: 12px; color: #6E6E73; margin-top: 6px;">Live news, financials & market trends</div>
            </div>
            <div style="background: #151515; border: 1px solid #272727; border-radius: 12px; padding: 20px;">
                <div style="font-size: 24px; margin-bottom: 10px;">🎭</div>
                <div style="font-size: 13px; font-weight: 600; color: #F5F5F7;">8 Perspectives</div>
                <div style="font-size: 12px; color: #6E6E73; margin-top: 6px;">Student to Futurist to Contrarian</div>
            </div>
            <div style="background: #151515; border: 1px solid #272727; border-radius: 12px; padding: 20px;">
                <div style="font-size: 24px; margin-bottom: 10px;">📊</div>
                <div style="font-size: 13px; font-weight: 600; color: #F5F5F7;">Rich Visualizations</div>
                <div style="font-size: 12px; color: #6E6E73; margin-top: 6px;">9 interactive Plotly charts</div>
            </div>
            <div style="background: #151515; border: 1px solid #272727; border-radius: 12px; padding: 20px;">
                <div style="font-size: 24px; margin-bottom: 10px;">📁</div>
                <div style="font-size: 13px; font-weight: 600; color: #F5F5F7;">Export Reports</div>
                <div style="font-size: 12px; color: #6E6E73; margin-top: 6px;">JSON & PDF download</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
