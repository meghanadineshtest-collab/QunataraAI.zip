"""
formatter.py — Quantara AI
Handles report export: JSON and PDF generation.
"""

import os
import json
from datetime import datetime
from pathlib import Path
from typing import Optional


REPORTS_DIR = Path("quantara_reports")


def ensure_reports_dir():
    REPORTS_DIR.mkdir(exist_ok=True)
    (REPORTS_DIR / "json").mkdir(exist_ok=True)
    (REPORTS_DIR / "pdf").mkdir(exist_ok=True)


def _safe_filename(topic: str) -> str:
    clean = "".join(c if c.isalnum() or c in " _-" else "_" for c in topic)
    clean = clean.replace(" ", "_")[:50]
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"quantara_{clean}_{ts}"


# ─────────────────────────────────────────────────────────────────────────────
# JSON EXPORT
# ─────────────────────────────────────────────────────────────────────────────

def save_report_json(topic: str, data: dict, report: dict, roles: list[dict]) -> Path:
    ensure_reports_dir()
    full = {
        "meta": {
            "product": "Quantara AI",
            "version": "1.0.0",
            "topic": topic,
            "generated_at": datetime.now().isoformat(),
        },
        "raw_data": {
            "financial": data.get("financial", {}),
            "sentiment": data.get("sentiment", {}),
            "trends": {
                "labels": data.get("trends", {}).get("labels", [])[:10],
                "values": data.get("trends", {}).get("values", [])[:10],
            },
            "news": data.get("news", [])[:10],
        },
        "report": report,
        "role_analyses": roles,
    }

    filename = _safe_filename(topic) + ".json"
    path = REPORTS_DIR / "json" / filename
    with open(path, "w", encoding="utf-8") as f:
        json.dump(full, f, indent=2, ensure_ascii=False, default=str)

    return path


# ─────────────────────────────────────────────────────────────────────────────
# PDF EXPORT
# ─────────────────────────────────────────────────────────────────────────────

def save_report_pdf(topic: str, data: dict, report: dict, roles: list[dict]) -> Optional[Path]:
    """
    Generate a professional PDF report. Uses ReportLab if available.
    Falls back to an HTML report if ReportLab is not installed.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
            HRFlowable, PageBreak,
        )
        return _build_pdf_reportlab(topic, data, report, roles)
    except ImportError:
        return _build_pdf_html(topic, data, report, roles)


def _build_pdf_reportlab(topic: str, data: dict, report: dict, roles: list[dict]) -> Path:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        HRFlowable, PageBreak,
    )

    ensure_reports_dir()
    filename = _safe_filename(topic) + ".pdf"
    path = REPORTS_DIR / "pdf" / filename

    doc = SimpleDocTemplate(str(path), pagesize=A4,
                             leftMargin=2*cm, rightMargin=2*cm,
                             topMargin=2*cm, bottomMargin=2*cm)

    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle("Title", parent=styles["Title"],
                                  fontSize=22, textColor=colors.HexColor("#0A84FF"),
                                  spaceAfter=6)
    subtitle_style = ParagraphStyle("Subtitle", parent=styles["Normal"],
                                     fontSize=11, textColor=colors.HexColor("#8E8E93"),
                                     spaceAfter=20)
    h1_style = ParagraphStyle("H1", parent=styles["Heading1"],
                               fontSize=16, textColor=colors.HexColor("#0A84FF"),
                               spaceBefore=16, spaceAfter=8)
    h2_style = ParagraphStyle("H2", parent=styles["Heading2"],
                               fontSize=13, textColor=colors.HexColor("#FFFFFF"),
                               spaceBefore=12, spaceAfter=6,
                               backColor=colors.HexColor("#1C1C1E"),
                               leftIndent=8, rightIndent=8, topPadding=4, bottomPadding=4)
    body_style = ParagraphStyle("Body", parent=styles["Normal"],
                                 fontSize=10, leading=16,
                                 textColor=colors.HexColor("#2C2C2E"),
                                 spaceAfter=8)
    bullet_style = ParagraphStyle("Bullet", parent=body_style,
                                   leftIndent=20, bulletIndent=10)

    story = []
    fin = data.get("financial", {})
    sentiment = data.get("sentiment", {})

    def fmt_number(n):
        if not n:
            return "N/A"
        n = float(n)
        if n >= 1e12:
            return f"${n/1e12:.2f}T"
        if n >= 1e9:
            return f"${n/1e9:.2f}B"
        if n >= 1e6:
            return f"${n/1e6:.2f}M"
        return f"${n:,.0f}"

    # ── Cover Page ──────────────────────────────────────────────────────────
    story.append(Spacer(1, 2*cm))
    story.append(Paragraph("QUANTARA AI", ParagraphStyle("Brand",
        fontSize=11, textColor=colors.HexColor("#0A84FF"), letterSpacing=3)))
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph(f"Institutional Research Report", subtitle_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#0A84FF"), thickness=2))
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph(topic.upper(), ParagraphStyle("Topic",
        fontSize=28, textColor=colors.HexColor("#0D0D0D"), leading=34, spaceAfter=20)))
    story.append(Paragraph(
        f"Generated: {datetime.now().strftime('%B %d, %Y at %H:%M')} UTC",
        subtitle_style))

    # Financial snapshot table
    fin_data = [
        ["Ticker", fin.get("ticker", "N/A"), "Market Cap", fmt_number(fin.get("market_cap", 0))],
        ["Price", f"${fin.get('current_price', 0):,.2f}", "Revenue", fmt_number(fin.get("revenue", 0))],
        ["PE Ratio", str(fin.get("pe_ratio", "N/A")), "Sentiment", sentiment.get("label", "N/A")],
        ["52W High", f"${fin.get('52w_high', 0):,.2f}", "52W Low", f"${fin.get('52w_low', 0):,.2f}"],
    ]
    tbl = Table(fin_data, colWidths=[3.5*cm, 5*cm, 3.5*cm, 5*cm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F8F9FA")),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#E8F4FD")),
        ("BACKGROUND", (2, 0), (2, -1), colors.HexColor("#E8F4FD")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DEE2E6")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
    ]))
    story.append(tbl)
    story.append(PageBreak())

    # ── Executive Summary ───────────────────────────────────────────────────
    story.append(Paragraph("01. Executive Summary", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    exec_sum = report.get("executive_summary", "")
    for para in exec_sum.split("\n\n"):
        if para.strip():
            story.append(Paragraph(para.strip(), body_style))

    # ── Key Insights ────────────────────────────────────────────────────────
    story.append(Paragraph("02. Key Insights", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    for insight in report.get("key_insights", []):
        story.append(Paragraph(f"• {insight}", bullet_style))

    # ── Market Analysis ─────────────────────────────────────────────────────
    story.append(Paragraph("03. Market Analysis", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    mkt = report.get("market_analysis", {})
    if mkt:
        mkt_data = [
            ["Total Market Size", str(mkt.get("total_market_size", "N/A"))],
            ["CAGR", f"{mkt.get('cagr_pct', 0):.1f}%"],
            ["Penetration Rate", f"{mkt.get('current_penetration_pct', 0):.1f}%"],
        ]
        tam = mkt.get("tam_sam_som", {})
        if tam:
            mkt_data += [
                ["TAM", str(tam.get("TAM", "N/A"))],
                ["SAM", str(tam.get("SAM", "N/A"))],
                ["SOM", str(tam.get("SOM", "N/A"))],
            ]
        mkt_tbl = Table(mkt_data, colWidths=[6*cm, 11*cm])
        mkt_tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#E8F4FD")),
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DEE2E6")),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(mkt_tbl)
        story.append(Spacer(1, 0.3*cm))
        if mkt.get("commentary"):
            story.append(Paragraph(mkt["commentary"], body_style))

    # ── Opportunities ────────────────────────────────────────────────────────
    story.append(Paragraph("04. Opportunities", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    for opp in report.get("opportunities", []):
        story.append(Paragraph(f"<b>▶ {opp.get('title','')}</b>", ParagraphStyle("BulletHead",
            parent=body_style, textColor=colors.HexColor("#30D158"))))
        story.append(Paragraph(opp.get("description", ""), body_style))

    # ── Risks ────────────────────────────────────────────────────────────────
    story.append(Paragraph("05. Risks", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    for risk in report.get("risks", []):
        story.append(Paragraph(f"<b>⚠ {risk.get('title','')} [{risk.get('severity','').upper()}]</b>",
            ParagraphStyle("RiskHead", parent=body_style, textColor=colors.HexColor("#FF453A"))))
        story.append(Paragraph(risk.get("description", ""), body_style))
        if risk.get("mitigation"):
            story.append(Paragraph(f"Mitigation: {risk['mitigation']}", ParagraphStyle("Miti",
                parent=body_style, textColor=colors.HexColor("#636366"), fontSize=9)))

    # ── Future Scope ─────────────────────────────────────────────────────────
    story.append(Paragraph("06. Future Scope", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    future = report.get("future_scope", "")
    for para in future.split("\n\n"):
        if para.strip():
            clean = para.replace("**", "").strip()
            story.append(Paragraph(clean, body_style))

    # ── Strategic Recommendations ─────────────────────────────────────────
    story.append(Paragraph("07. Strategic Recommendations", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    for i, rec in enumerate(report.get("strategic_recommendations", []), 1):
        story.append(Paragraph(f"<b>{i}. {rec.get('recommendation','')}</b>",
            ParagraphStyle("RecHead", parent=body_style, textColor=colors.HexColor("#0A84FF"))))
        story.append(Paragraph(f"Rationale: {rec.get('rationale','')}", body_style))
        story.append(Paragraph(f"Expected Outcome: {rec.get('expected_outcome','')}", ParagraphStyle("Outcome",
            parent=body_style, textColor=colors.HexColor("#30D158"), fontSize=9)))
        story.append(Spacer(1, 0.2*cm))

    # ── Role Analyses ─────────────────────────────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("08. Multi-Role Analytical Perspectives", h1_style))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E0E0E0"), thickness=0.5))
    story.append(Spacer(1, 0.3*cm))
    for role in roles:
        story.append(Paragraph(role.get("label", ""), h2_style))
        story.append(Spacer(1, 0.2*cm))
        for para in role.get("analysis", "").split("\n\n"):
            if para.strip():
                story.append(Paragraph(para.strip(), body_style))
        story.append(Spacer(1, 0.5*cm))

    doc.build(story)
    return path


def _build_pdf_html(topic: str, data: dict, report: dict, roles: list[dict]) -> Path:
    """Fallback: generate HTML file when ReportLab is unavailable."""
    ensure_reports_dir()
    filename = _safe_filename(topic) + ".html"
    path = REPORTS_DIR / "pdf" / filename

    fin = data.get("financial", {})
    sentiment = data.get("sentiment", {})

    def fmt_number(n):
        if not n:
            return "N/A"
        n = float(n)
        if n >= 1e12:
            return f"${n/1e12:.2f}T"
        if n >= 1e9:
            return f"${n/1e9:.2f}B"
        if n >= 1e6:
            return f"${n/1e6:.2f}M"
        return f"${n:,.0f}"

    def section(title, content):
        return f"<h2>{title}</h2><div class='section-content'>{content}</div>"

    insights_html = "".join(f"<li>{i}</li>" for i in report.get("key_insights", []))
    opps_html = "".join(
        f"<div class='card green'><h3>{o['title']}</h3><p>{o['description']}</p>"
        f"<span class='badge'>Probability: {o.get('probability_pct',50)}%</span></div>"
        for o in report.get("opportunities", [])
    )
    risks_html = "".join(
        f"<div class='card red'><h3>{r['title']} <span class='badge red'>{r.get('severity','').upper()}</span></h3>"
        f"<p>{r['description']}</p><p><em>Mitigation: {r.get('mitigation','')}</em></p></div>"
        for r in report.get("risks", [])
    )
    recs_html = "".join(
        f"<div class='card blue'><h3>{i+1}. {r['recommendation']}</h3>"
        f"<p>{r['rationale']}</p><p class='outcome'>{r.get('expected_outcome','')}</p></div>"
        for i, r in enumerate(report.get("strategic_recommendations", []))
    )
    roles_html = "".join(
        f"<div class='role-card'><h3>{r['icon']} {r['label']}</h3>"
        f"<p>{r['analysis'].replace(chr(10), '<br>')}</p></div>"
        for r in roles
    )

    html = f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8">
<title>Quantara AI — {topic}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: 'Helvetica Neue', Arial, sans-serif; color: #1a1a1a; max-width: 900px; margin: 0 auto; padding: 40px 30px; }}
  h1 {{ font-size: 32px; color: #0A84FF; margin-bottom: 6px; }}
  h2 {{ font-size: 18px; color: #0A84FF; margin: 32px 0 12px; border-bottom: 2px solid #0A84FF; padding-bottom: 6px; }}
  h3 {{ font-size: 14px; margin-bottom: 8px; }}
  p {{ line-height: 1.7; margin-bottom: 10px; font-size: 14px; }}
  .brand {{ letter-spacing: 3px; font-size: 12px; color: #0A84FF; font-weight: 600; }}
  .meta {{ color: #636366; font-size: 13px; margin: 8px 0 30px; }}
  hr {{ border: none; border-top: 1px solid #E0E0E0; margin: 20px 0; }}
  table {{ width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 13px; }}
  th, td {{ padding: 8px 12px; border: 1px solid #E0E0E0; text-align: left; }}
  th {{ background: #E8F4FD; font-weight: 600; }}
  ul {{ padding-left: 20px; margin: 10px 0; }}
  li {{ margin: 8px 0; font-size: 14px; line-height: 1.6; }}
  .card {{ border-radius: 8px; padding: 16px; margin: 12px 0; border-left: 4px solid #ccc; background: #f9f9f9; }}
  .card.green {{ border-left-color: #30D158; }}
  .card.red {{ border-left-color: #FF453A; }}
  .card.blue {{ border-left-color: #0A84FF; }}
  .badge {{ display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; background: #E8F4FD; color: #0A84FF; }}
  .badge.red {{ background: #FFE5E5; color: #FF453A; }}
  .outcome {{ color: #30D158; font-size: 13px; }}
  .role-card {{ border: 1px solid #E0E0E0; border-radius: 8px; padding: 20px; margin: 16px 0; }}
  .role-card h3 {{ font-size: 15px; margin-bottom: 12px; color: #0A84FF; }}
</style>
</head><body>
<div class="brand">QUANTARA AI</div>
<h1>{topic}</h1>
<div class="meta">Institutional Research Report · Generated {datetime.now().strftime('%B %d, %Y at %H:%M')} UTC</div>

<table>
<tr><th>Ticker</th><td>{fin.get('ticker','N/A')}</td><th>Market Cap</th><td>{fmt_number(fin.get('market_cap',0))}</td></tr>
<tr><th>Price</th><td>${fin.get('current_price',0):,.2f}</td><th>Revenue</th><td>{fmt_number(fin.get('revenue',0))}</td></tr>
<tr><th>PE Ratio</th><td>{fin.get('pe_ratio','N/A')}</td><th>Sentiment</th><td>{sentiment.get('label','N/A')}</td></tr>
</table>

{section("Executive Summary", f"<p>{report.get('executive_summary','').replace(chr(10), '<br>')}</p>")}
{section("Key Insights", f"<ul>{insights_html}</ul>")}
{section("Opportunities", opps_html)}
{section("Risks", risks_html)}
{section("Future Scope", f"<p>{report.get('future_scope','').replace(chr(10), '<br>')}</p>")}
{section("Strategic Recommendations", recs_html)}
{section("Multi-Role Analytical Perspectives", roles_html)}
</body></html>"""

    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path
