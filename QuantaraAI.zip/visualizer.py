"""
visualizer.py — Quantara AI
Generates all charts and visualizations using Plotly.
Returns Plotly figures that Streamlit renders natively.
"""

import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
from typing import Optional

# Brand palette
PALETTE = {
    "primary": "#0A84FF",
    "positive": "#30D158",
    "negative": "#FF453A",
    "neutral": "#636366",
    "warning": "#FFD60A",
    "purple": "#BF5AF2",
    "teal": "#5AC8FA",
    "bg": "#0D0D0D",
    "card": "#1C1C1E",
    "border": "#2C2C2E",
    "text": "#FFFFFF",
    "text_muted": "#8E8E93",
}

PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="'SF Pro Display', 'Helvetica Neue', Arial, sans-serif", color=PALETTE["text"]),
    margin=dict(l=20, r=20, t=40, b=20),
    hoverlabel=dict(bgcolor=PALETTE["card"], font_size=13, font_family="Arial"),
)

ROLE_COLORS = [
    "#0A84FF", "#30D158", "#FF9F0A", "#FF453A",
    "#BF5AF2", "#5AC8FA", "#FF6B6B", "#A8DADC",
]


# ─────────────────────────────────────────────────────────────────────────────
# PRICE HISTORY LINE CHART
# ─────────────────────────────────────────────────────────────────────────────

def plot_price_history(financial: dict) -> go.Figure:
    price_history = financial.get("price_history", [])
    if not price_history:
        return _empty_figure("No price data available")

    df = pd.DataFrame(price_history)
    df["date"] = pd.to_datetime(df["date"])

    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.08,
        row_heights=[0.75, 0.25],
    )

    # Price line with gradient fill
    fig.add_trace(
        go.Scatter(
            x=df["date"], y=df["close"],
            mode="lines",
            line=dict(color=PALETTE["primary"], width=2.5),
            fill="tozeroy",
            fillcolor="rgba(10, 132, 255, 0.08)",
            name="Close Price",
            hovertemplate="<b>%{x|%b %d, %Y}</b><br>Price: $%{y:,.2f}<extra></extra>",
        ),
        row=1, col=1
    )

    # Volume bars
    colors = [PALETTE["positive"] if i == 0 or df["close"].iloc[i] >= df["close"].iloc[i-1]
              else PALETTE["negative"] for i in range(len(df))]
    fig.add_trace(
        go.Bar(
            x=df["date"], y=df["volume"],
            name="Volume",
            marker_color=colors,
            marker_opacity=0.6,
            hovertemplate="<b>%{x|%b %d, %Y}</b><br>Volume: %{y:,.0f}<extra></extra>",
        ),
        row=2, col=1
    )

    ticker = financial.get("ticker", "")
    name = financial.get("name", "")

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(
            text=f"{ticker} — 6 Month Price & Volume",
            font=dict(size=16, color=PALETTE["text"]),
        ),
        xaxis=dict(showgrid=False, showline=False, zeroline=False),
        yaxis=dict(
            showgrid=True, gridcolor=PALETTE["border"],
            tickprefix="$", tickformat=",.0f",
        ),
        yaxis2=dict(
            showgrid=False, tickformat=".2s",
        ),
        showlegend=False,
        height=380,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# SENTIMENT PIE CHART
# ─────────────────────────────────────────────────────────────────────────────

def plot_sentiment_pie(sentiment: dict) -> go.Figure:
    labels = ["Positive", "Neutral", "Negative"]
    values = [
        sentiment.get("positive_pct", 33),
        sentiment.get("neutral_pct", 33),
        sentiment.get("negative_pct", 34),
    ]
    colors = [PALETTE["positive"], PALETTE["neutral"], PALETTE["negative"]]

    fig = go.Figure(go.Pie(
        labels=labels,
        values=values,
        hole=0.6,
        marker=dict(colors=colors, line=dict(color=PALETTE["bg"], width=2)),
        textinfo="percent",
        textfont=dict(size=13, color="white"),
        hovertemplate="<b>%{label}</b><br>%{value:.1f}%<extra></extra>",
    ))

    score = sentiment.get("composite_score", 0)
    label = sentiment.get("label", "Neutral")
    score_color = PALETTE["positive"] if score > 0.1 else (PALETTE["negative"] if score < -0.1 else PALETTE["neutral"])

    fig.add_annotation(
        text=f"<b>{label}</b><br><span style='font-size:12px'>{score:+.3f}</span>",
        x=0.5, y=0.5,
        showarrow=False,
        font=dict(size=15, color=score_color),
        align="center",
    )

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text="Market Sentiment", font=dict(size=16)),
        showlegend=True,
        legend=dict(
            orientation="h", x=0.5, y=-0.15, xanchor="center",
            font=dict(color=PALETTE["text"]),
        ),
        height=300,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# MARKET SHARE PIE CHART
# ─────────────────────────────────────────────────────────────────────────────

def plot_market_share(competitor_analysis: list[dict]) -> go.Figure:
    if not competitor_analysis:
        return _empty_figure("No competitor data")

    names = [c.get("name", f"Company {i+1}") for i, c in enumerate(competitor_analysis)]
    shares = [c.get("market_share_pct", 20) for c in competitor_analysis]

    # Normalize
    total = sum(shares)
    if total != 100 and total > 0:
        others = max(0, 100 - total)
        if others > 2:
            names.append("Others")
            shares.append(others)

    fig = go.Figure(go.Pie(
        labels=names,
        values=shares,
        hole=0.4,
        marker=dict(
            colors=ROLE_COLORS[:len(names)],
            line=dict(color=PALETTE["bg"], width=2),
        ),
        textinfo="label+percent",
        textfont=dict(size=11),
        hovertemplate="<b>%{label}</b><br>Share: %{value:.1f}%<extra></extra>",
    ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text="Estimated Market Share Distribution", font=dict(size=16)),
        showlegend=False,
        height=350,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# COMPETITOR MOAT RADAR
# ─────────────────────────────────────────────────────────────────────────────

def plot_competitor_comparison(competitor_analysis: list[dict]) -> go.Figure:
    if not competitor_analysis:
        return _empty_figure("No competitor data")

    fig = go.Figure()
    categories = ["Market Share", "Moat Rating", "Innovation", "Scale", "Brand"]

    import random
    for i, comp in enumerate(competitor_analysis[:5]):
        rng = random.Random(hash(comp.get("name", i)) % 9999)
        moat = comp.get("moat_rating", 5)
        share = min(10, comp.get("market_share_pct", 20) / 4)

        values = [
            share,
            moat,
            rng.uniform(4, 9),
            rng.uniform(3, 9),
            rng.uniform(4, 9),
        ]
        values.append(values[0])
        cats = categories + [categories[0]]

        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=cats,
            fill="toself",
            name=comp.get("name", f"Company {i+1}"),
            line=dict(color=ROLE_COLORS[i % len(ROLE_COLORS)], width=2),
            fillcolor=f"rgba{tuple(list(_hex_to_rgb(ROLE_COLORS[i % len(ROLE_COLORS)])) + [0.08])}",
        ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 10],
                showticklabels=False,
                gridcolor=PALETTE["border"],
            ),
            angularaxis=dict(
                gridcolor=PALETTE["border"],
                linecolor=PALETTE["border"],
            ),
            bgcolor="rgba(0,0,0,0)",
        ),
        title=dict(text="Competitive Landscape Radar", font=dict(size=16)),
        showlegend=True,
        legend=dict(font=dict(color=PALETTE["text"]), bgcolor="rgba(0,0,0,0)"),
        height=380,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# TRENDS LINE CHART
# ─────────────────────────────────────────────────────────────────────────────

def plot_trends(trends: dict, topic: str) -> go.Figure:
    labels = trends.get("labels", [])
    values = trends.get("values", [])

    if not labels or not values:
        return _empty_figure("No trend data")

    fig = go.Figure()

    # Smoothed trend line
    fig.add_trace(go.Scatter(
        x=labels, y=values,
        mode="lines",
        line=dict(color=PALETTE["purple"], width=2.5, shape="spline", smoothing=0.8),
        fill="tozeroy",
        fillcolor="rgba(191, 90, 242, 0.08)",
        name="Interest",
        hovertemplate="<b>%{x}</b><br>Interest: %{y}<extra></extra>",
    ))

    # Rolling average
    if len(values) >= 4:
        window = 4
        rolling = [sum(values[max(0, i-window):i+1]) / min(window, i+1) for i in range(len(values))]
        fig.add_trace(go.Scatter(
            x=labels, y=rolling,
            mode="lines",
            line=dict(color=PALETTE["teal"], width=1.5, dash="dot"),
            name="Moving Avg",
            hovertemplate="<b>%{x}</b><br>4W Avg: %{y:.1f}<extra></extra>",
        ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text=f"'{topic}' — Search Interest Over Time", font=dict(size=16)),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor=PALETTE["border"], title="Interest (0-100)"),
        showlegend=True,
        legend=dict(font=dict(color=PALETTE["text"]), bgcolor="rgba(0,0,0,0)"),
        height=300,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# OPPORTUNITIES vs RISKS MATRIX
# ─────────────────────────────────────────────────────────────────────────────

def plot_opportunity_risk_matrix(opportunities: list[dict], risks: list[dict]) -> go.Figure:
    fig = go.Figure()

    impact_map = {"high": 3, "medium": 2, "low": 1}
    severity_map = {"critical": 4, "high": 3, "medium": 2, "low": 1}

    # Opportunities (green)
    for opp in opportunities:
        fig.add_trace(go.Scatter(
            x=[opp.get("probability_pct", 50)],
            y=[impact_map.get(opp.get("impact", "medium").lower(), 2) * 3],
            mode="markers+text",
            marker=dict(
                size=18,
                color=PALETTE["positive"],
                symbol="circle",
                line=dict(color="white", width=1.5),
            ),
            text=[opp.get("title", "")[:20]],
            textposition="top center",
            textfont=dict(size=10, color=PALETTE["text"]),
            name="Opportunities",
            legendgroup="opportunities",
            showlegend=True if opp == opportunities[0] else False,
            hovertemplate=f"<b>{opp.get('title','')}</b><br>Probability: {opp.get('probability_pct',50)}%<br>Impact: {opp.get('impact','').upper()}<extra></extra>",
        ))

    # Risks (red)
    for risk in risks:
        fig.add_trace(go.Scatter(
            x=[risk.get("likelihood_pct", 40)],
            y=[severity_map.get(risk.get("severity", "medium").lower(), 2) * 2.5],
            mode="markers+text",
            marker=dict(
                size=18,
                color=PALETTE["negative"],
                symbol="diamond",
                line=dict(color="white", width=1.5),
            ),
            text=[risk.get("title", "")[:20]],
            textposition="top center",
            textfont=dict(size=10, color=PALETTE["text"]),
            name="Risks",
            legendgroup="risks",
            showlegend=True if risk == risks[0] else False,
            hovertemplate=f"<b>{risk.get('title','')}</b><br>Likelihood: {risk.get('likelihood_pct',40)}%<br>Severity: {risk.get('severity','').upper()}<extra></extra>",
        ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text="Opportunity & Risk Matrix", font=dict(size=16)),
        xaxis=dict(
            title="Probability / Likelihood (%)",
            showgrid=True, gridcolor=PALETTE["border"],
            range=[0, 100],
        ),
        yaxis=dict(
            title="Impact / Severity",
            showgrid=True, gridcolor=PALETTE["border"],
        ),
        showlegend=True,
        legend=dict(font=dict(color=PALETTE["text"]), bgcolor="rgba(0,0,0,0)"),
        height=380,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# TAM / SAM / SOM BAR CHART
# ─────────────────────────────────────────────────────────────────────────────

def plot_tam_sam_som(market_analysis: dict) -> go.Figure:
    tam_sam_som = market_analysis.get("tam_sam_som", {})
    if not tam_sam_som:
        return _empty_figure("No market size data")

    def parse_val(v):
        if not v:
            return 0
        v = str(v).replace("$", "").replace(",", "").strip()
        if v.endswith("T"):
            return float(v[:-1]) * 1e12
        if v.endswith("B"):
            return float(v[:-1]) * 1e9
        if v.endswith("M"):
            return float(v[:-1]) * 1e6
        try:
            return float(v)
        except:
            return 0

    labels = ["TAM\n(Total Market)", "SAM\n(Serviceable)", "SOM\n(Obtainable)"]
    values = [
        parse_val(tam_sam_som.get("TAM", 0)),
        parse_val(tam_sam_som.get("SAM", 0)),
        parse_val(tam_sam_som.get("SOM", 0)),
    ]
    colors = [PALETTE["primary"], PALETTE["teal"], PALETTE["positive"]]

    def fmt(v):
        if v >= 1e12:
            return f"${v/1e12:.1f}T"
        if v >= 1e9:
            return f"${v/1e9:.1f}B"
        if v >= 1e6:
            return f"${v/1e6:.0f}M"
        return f"${v:,.0f}"

    fig = go.Figure(go.Bar(
        x=labels,
        y=values,
        marker=dict(
            color=colors,
            line=dict(color=PALETTE["bg"], width=1),
        ),
        text=[fmt(v) for v in values],
        textposition="outside",
        textfont=dict(color=PALETTE["text"], size=13),
        hovertemplate="<b>%{x}</b><br>%{text}<extra></extra>",
    ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text="Market Sizing: TAM → SAM → SOM", font=dict(size=16)),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor=PALETTE["border"], showticklabels=False),
        height=320,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# RISK SEVERITY BAR CHART
# ─────────────────────────────────────────────────────────────────────────────

def plot_risk_matrix(risks: list[dict]) -> go.Figure:
    if not risks:
        return _empty_figure("No risk data")

    severity_score = {"critical": 4, "high": 3, "medium": 2, "low": 1}
    severity_color = {
        "critical": PALETTE["negative"],
        "high": "#FF6B35",
        "medium": PALETTE["warning"],
        "low": PALETTE["positive"],
    }

    titles = [r.get("title", f"Risk {i+1}") for i, r in enumerate(risks)]
    likelihood = [r.get("likelihood_pct", 40) for r in risks]
    severities = [r.get("severity", "medium") for r in risks]
    colors = [severity_color.get(s.lower(), PALETTE["neutral"]) for s in severities]

    fig = go.Figure(go.Bar(
        x=likelihood,
        y=titles,
        orientation="h",
        marker=dict(color=colors, line=dict(color=PALETTE["bg"], width=1)),
        text=[f"{l}%" for l in likelihood],
        textposition="outside",
        textfont=dict(color=PALETTE["text"], size=12),
        hovertemplate="<b>%{y}</b><br>Likelihood: %{x}%<extra></extra>",
    ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text="Risk Likelihood Assessment", font=dict(size=16)),
        xaxis=dict(
            showgrid=True, gridcolor=PALETTE["border"],
            range=[0, 100], ticksuffix="%",
        ),
        yaxis=dict(showgrid=False, autorange="reversed"),
        height=300,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# NEWS SENTIMENT BAR
# ─────────────────────────────────────────────────────────────────────────────

def plot_news_sentiment(news: list[dict]) -> go.Figure:
    if not news:
        return _empty_figure("No news data")

    sources = {}
    for n in news:
        src = n.get("source", "Unknown")
        s = n.get("sentiment", "neutral")
        if src not in sources:
            sources[src] = {"positive": 0, "neutral": 0, "negative": 0}
        sources[src][s] += 1

    src_labels = list(sources.keys())[:8]
    pos = [sources[s].get("positive", 0) for s in src_labels]
    neu = [sources[s].get("neutral", 0) for s in src_labels]
    neg = [sources[s].get("negative", 0) for s in src_labels]

    fig = go.Figure()
    fig.add_trace(go.Bar(name="Positive", x=src_labels, y=pos, marker_color=PALETTE["positive"]))
    fig.add_trace(go.Bar(name="Neutral", x=src_labels, y=neu, marker_color=PALETTE["neutral"]))
    fig.add_trace(go.Bar(name="Negative", x=src_labels, y=neg, marker_color=PALETTE["negative"]))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        barmode="stack",
        title=dict(text="News Sentiment by Source", font=dict(size=16)),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor=PALETTE["border"]),
        legend=dict(font=dict(color=PALETTE["text"]), bgcolor="rgba(0,0,0,0)"),
        height=300,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _empty_figure(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message, x=0.5, y=0.5,
        showarrow=False, font=dict(size=14, color=PALETTE["text_muted"]),
    )
    fig.update_layout(**PLOTLY_LAYOUT, height=200)
    return fig


def _hex_to_rgb(hex_color: str) -> tuple:
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
